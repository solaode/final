//
//  ContentView.swift
//  Location
//
//  Created by Mousumi Chakrabarty on 11/16/23.
//

import MapKit
import SwiftUI

struct ContentView: View {
    
    @StateObject var manager = LocationManager()
    
    var body: some View {
        Map(coordinateRegion: $manager.region, showsUserLocation: true)
            .edgesIgnoringSafeArea(.all)
    }
}
